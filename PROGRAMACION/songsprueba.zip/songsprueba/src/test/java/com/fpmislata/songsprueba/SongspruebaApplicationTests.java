package com.fpmislata.songsprueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SongspruebaApplicationTests {

	@Test
	void contextLoads() {
	}

}
