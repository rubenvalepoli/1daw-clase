package com.fpmislata.songsprueba.persistence.impl;

import com.fpmislata.songsprueba.domine.entity.Song;
import com.fpmislata.songsprueba.persistence.SongRepository;

import java.util.ArrayList;
import java.util.List;

public class SongRepositpryImpl implements SongRepository {

    public List<Song> songList = new ArrayList<>();

    public SongRepositpryImpl(){
        songList.add(new Song(1,"Un beso y una flor",1973));
        songList.add(new Song(2,"Me matas",2020));
        songList.add(new Song(3,"Todos los dias sale el sol",2010));
        songList.add(new Song(4,"Sirenas",2013));
    }


    @Override
    public List<Song> all() {
        return this.songList;
    }

    @Override
    public Song findById(Integer id) {
        for (Song song : songList){
            if (song.getId() == id){
                return song;
            }
        }
        return null;
    }
}
