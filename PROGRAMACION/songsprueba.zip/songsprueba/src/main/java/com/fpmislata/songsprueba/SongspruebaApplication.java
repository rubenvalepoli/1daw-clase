package com.fpmislata.songsprueba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SongspruebaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SongspruebaApplication.class, args);
	}

}
