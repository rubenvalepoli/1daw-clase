package com.fpmislata.songsprueba.domine.service.impl;

import com.fpmislata.songsprueba.domine.entity.Song;
import com.fpmislata.songsprueba.domine.service.SongService;
import com.fpmislata.songsprueba.persistence.SongRepository;
import com.fpmislata.songsprueba.persistence.impl.SongRepositpryImpl;

import java.util.List;

public class SongServiceImpl implements SongService {

    private SongRepository repository = new SongRepositpryImpl();


    @Override
    public List<Song> getAll() {
        return this.repository.all();
    }

    @Override
    public Song findById(Integer id) {
        return this.repository.findById(id);
    }
}
