package com.fpmislata.examen2.domain.service;

import com.fpmislata.examen2.domain.entity.Director;

import java.util.List;

public interface DirectorService {
    public List<Director> getAll();
}
