package com.fpmislata.examen2.persistence.repository;

public interface CharacterMovieRepository {
}
