package com.fpmislata.examen2.persistence.dao;

import com.fpmislata.examen2.persistence.dao.entity.ActorEntity;

public interface ActorDao {

    public ActorEntity findById(Integer id);
}
