package com.fpmislata.examen2.domain.service;

public interface CharacterMovieService {
}
