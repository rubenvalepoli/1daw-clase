package com.fpmislata.examen2.domain.service.impl;

import com.fpmislata.examen2.domain.service.MovieService;

public class MovieServiceImpl implements MovieService {

}
