package com.fpmislata.examen2.persistence.repository.impl;

import com.fpmislata.examen2.persistence.repository.MovieRepository;

public class MovieRepositoryImpl implements MovieRepository {

}
