package com.fpmislata.examen2.persistence.dao.entity;

public class DirectorEntity {

    private int id;
    private String name;

    public DirectorEntity(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
