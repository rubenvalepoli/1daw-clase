package com.fpmislata.examen2.persistence.dao;

public interface CharacterMovieDao {
}
