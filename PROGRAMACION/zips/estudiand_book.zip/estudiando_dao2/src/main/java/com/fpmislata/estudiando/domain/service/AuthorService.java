package com.fpmislata.estudiando.domain.service;

import com.fpmislata.estudiando.domain.entity.Author;

import java.util.List;

public interface AuthorService {

    public List<Author> findAll();
}
