package es.cesguiro.proyect1daw.persistence.dao.entity;

public class BookEntity {

    private Integer id;
    private String title;
    private int year;
    private int runtime;
}
