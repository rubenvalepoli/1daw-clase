package com.fpmislata.estudiando.persistence.impl;


import com.fpmislata.estudiando.domain.entity.Book;
import com.fpmislata.estudiando.persistence.BookRepository;

import java.util.ArrayList;
import java.util.List;

public class BookRepositoryImpl implements BookRepository {


    List<Book> bookList = new ArrayList<>();

    public BookRepositoryImpl(){
        this.bookList.add(new Book(1,"El Quijote"));
        this.bookList.add(new Book(2,"Sancho Panza"));
        this.bookList.add(new Book(3,"Panzeta"));
    }

    @Override
    public List<Book> findall() {
        return this.bookList;
    }
}
