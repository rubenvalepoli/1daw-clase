package com.fpmislata.examen.domain.service.impl;

import com.fpmislata.examen.domain.service.ExampleService;

public class ExampleServiceImpl implements ExampleService {
}
