package com.fpmislata.examen.persistence.repositoy.impl;

import com.fpmislata.examen.persistence.repositoy.ExampleRepository;

public class ExamenRepositoryImpl implements ExampleRepository {
}
