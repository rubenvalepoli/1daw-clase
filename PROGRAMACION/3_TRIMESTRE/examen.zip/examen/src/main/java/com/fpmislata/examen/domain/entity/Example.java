package com.fpmislata.examen.domain.entity;

public class Example {
}
