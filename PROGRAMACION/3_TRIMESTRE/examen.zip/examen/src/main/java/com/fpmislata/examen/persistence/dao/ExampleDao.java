package com.fpmislata.examen.persistence.dao;

public interface ExampleDao {
}
