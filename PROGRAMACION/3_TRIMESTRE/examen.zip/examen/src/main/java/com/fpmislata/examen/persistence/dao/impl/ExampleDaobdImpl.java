package com.fpmislata.examen.persistence.dao.impl;

import com.fpmislata.examen.persistence.dao.ExampleDao;

public class ExampleDaobdImpl implements ExampleDao {
}
