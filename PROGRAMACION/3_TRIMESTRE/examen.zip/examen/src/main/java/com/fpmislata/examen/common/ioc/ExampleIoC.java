package com.fpmislata.examen.common.ioc;

public class ExampleIoC {
}
