package com.fpmislata.examen.persistence.repositoy;

public interface ExampleRepository {
}
