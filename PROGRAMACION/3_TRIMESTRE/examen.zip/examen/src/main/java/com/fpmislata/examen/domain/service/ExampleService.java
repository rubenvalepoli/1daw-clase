package com.fpmislata.examen.domain.service;

public interface ExampleService {
}
