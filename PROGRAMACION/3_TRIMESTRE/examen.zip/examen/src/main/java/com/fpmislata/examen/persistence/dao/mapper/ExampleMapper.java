package com.fpmislata.examen.persistence.dao.mapper;

public class ExampleMapper {
}
