package com.fpmislata.examen.controller;

public class MainController {
}
