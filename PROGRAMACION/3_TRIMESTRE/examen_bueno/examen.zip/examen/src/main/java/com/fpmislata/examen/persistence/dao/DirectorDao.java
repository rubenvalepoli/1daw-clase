package com.fpmislata.examen.persistence.dao;

import com.fpmislata.examen.domain.entity.Director;

public interface DirectorDao {

    public Director findDirectorById(int id);

}
