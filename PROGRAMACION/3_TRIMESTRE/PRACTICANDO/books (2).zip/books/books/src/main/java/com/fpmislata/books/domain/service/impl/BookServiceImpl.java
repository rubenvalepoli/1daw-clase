package com.fpmislata.books.domain.service.impl;

import com.fpmislata.books.domain.entity.Book;
import com.fpmislata.books.domain.service.BookService;
import com.fpmislata.books.persistence.repository.BookRepository;

import java.util.List;

public class BookServiceImpl implements BookService {
    BookRepository bookRepository;

    public BookServiceImpl(BookService bookService) {
    }


    @Override
    public List<Book> findAll() {
        return bookRepository.findAll();
    }
}
