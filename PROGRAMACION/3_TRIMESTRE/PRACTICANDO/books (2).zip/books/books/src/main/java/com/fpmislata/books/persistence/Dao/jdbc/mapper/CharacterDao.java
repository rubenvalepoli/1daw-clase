package com.fpmislata.books.persistence.Dao.jdbc.mapper;

public class CharacterDao {
}
