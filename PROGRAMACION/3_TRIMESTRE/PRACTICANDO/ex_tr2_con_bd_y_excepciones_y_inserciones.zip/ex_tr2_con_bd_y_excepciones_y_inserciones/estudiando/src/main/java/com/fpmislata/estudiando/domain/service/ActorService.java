package com.fpmislata.estudiando.domain.service;

public interface ActorService {
}
