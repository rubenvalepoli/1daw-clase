package com.fpmislata.estudiando.domain.service;

public interface CharacterMovieService {
}
