package com.fpmislata.estudiando.domain.service;

import com.fpmislata.estudiando.domain.entity.Director;

import java.util.List;

public interface DirectorService {

    public List<Director> getAll();

}
