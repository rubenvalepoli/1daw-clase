package com.fpmislata.estudiando.persistence.repository;

public interface ActorRepository {
}
