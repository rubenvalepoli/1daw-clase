package com.fpmislata.estudiando.exceptions;

public class ResourceNotFoundException extends Exception{

    public ResourceNotFoundException (String messaje){}
}
