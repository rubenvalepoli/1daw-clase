package com.fpmislata.estudiando;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudiandoApplicationTests {

	@Test
	void contextLoads() {
	}

}
