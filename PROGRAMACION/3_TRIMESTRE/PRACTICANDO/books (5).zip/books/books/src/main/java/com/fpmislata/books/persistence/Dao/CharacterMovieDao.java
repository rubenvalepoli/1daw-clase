package com.fpmislata.books.persistence.Dao;

import com.fpmislata.books.domain.entity.CharacterMovie;

public interface CharacterMovieDao {
    public CharacterMovie findByCharacterId (int id);

}
