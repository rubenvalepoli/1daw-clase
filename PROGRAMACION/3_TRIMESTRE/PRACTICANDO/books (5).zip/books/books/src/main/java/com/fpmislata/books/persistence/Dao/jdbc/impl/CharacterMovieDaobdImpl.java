package com.fpmislata.books.persistence.Dao.jdbc.impl;

import com.fpmislata.books.domain.entity.CharacterMovie;
import com.fpmislata.books.persistence.Dao.CharacterMovieDao;
import com.fpmislata.books.persistence.Dao.jdbc.bd.Rawsql;
import com.fpmislata.books.persistence.Dao.jdbc.mapper.CharacterMovieMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class CharacterMovieDaobdImpl implements CharacterMovieDao {

    @Override
    public CharacterMovie findByCharacterId (int id){
        List<Object> listCharacterId = List.of(id);
        ResultSet resultSet = Rawsql.select("select * from characters where id=?;", listCharacterId);
        try {
            resultSet.next();
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
        return CharacterMovieMapper.toCharacterMovie(resultSet);
    }


}
