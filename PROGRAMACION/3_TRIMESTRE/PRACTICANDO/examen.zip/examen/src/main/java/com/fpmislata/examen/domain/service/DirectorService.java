package com.fpmislata.examen.domain.service;

import com.fpmislata.examen.domain.entity.Director;

public interface DirectorService {
    public Director findDirectorById(int id);
}
