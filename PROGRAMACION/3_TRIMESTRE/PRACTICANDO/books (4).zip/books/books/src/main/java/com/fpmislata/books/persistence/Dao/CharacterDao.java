package com.fpmislata.books.persistence.Dao;

import com.fpmislata.books.domain.entity.Book;

import java.util.List;

public interface CharacterDao {
    public List<Book> findId();
}
