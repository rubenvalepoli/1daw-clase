package com.fpmislata.books.persistence.repository.impl;

import com.fpmislata.books.domain.entity.Book;
import com.fpmislata.books.persistence.Dao.BookDao;
import com.fpmislata.books.persistence.Dao.CharacterDao;
import com.fpmislata.books.persistence.repository.BookRepository;

import java.util.List;

public class BookRepositoryImpl implements BookRepository {

    private BookDao bookDao;
    private CharacterDao characterDao;

    public BookRepositoryImpl(BookDao bookDao){
        this.bookDao = bookDao;
    }

    @Override
    public List<Book> findAll(){
        List<Book> bookList = bookDao.findAll();
      /*  for (Book book : bookList){
            int characterid = book.getCharacter().getId();
         Character id = characterDao.findId(clienteid);
            book.setCharacter(id);
        }*/
        return bookList;
    }

    @Override
    public Book findByBookId(int id){
        Book book = bookDao.findByBookId(id);
        return book;
    }


}
