package com.cipfpmislata.Ex3t_books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex3tBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
