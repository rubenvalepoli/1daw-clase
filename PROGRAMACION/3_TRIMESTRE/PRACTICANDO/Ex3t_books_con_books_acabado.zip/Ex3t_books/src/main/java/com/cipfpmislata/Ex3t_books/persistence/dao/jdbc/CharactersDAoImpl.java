package com.cipfpmislata.Ex3t_books.persistence.dao.jdbc;

import com.cipfpmislata.Ex3t_books.domain.entity.Characters;
import com.cipfpmislata.Ex3t_books.persistence.dao.CharactersDao;
import com.cipfpmislata.Ex3t_books.persistence.dao.jdbc.db.Rawsql;
import com.cipfpmislata.Ex3t_books.persistence.dao.mapper.CharacterMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CharactersDAoImpl implements CharactersDao {

    @Override
    public List<Characters> findAll() {
        try {
            List<Object> params= new ArrayList<>();
            String sql = "select * from characters where id=?";
            ResultSet resultSet= Rawsql.select(sql,params);
            resultSet.next();
            return CharacterMapper.toCharacters(resultSet);
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public Characters findByCharacterMovieId(int id) {
        return null;
    }

    @Override
    public List<Characters> findByMovie(Integer id) {
        return null;
    }
}
