package com.cipfpmislata.Ex3t_books.common.exceptions;

public class ObjectException extends RuntimeException{
    public ObjectException(String message){
        super(message);
    }

}
