package com.fpmislata.books.persistence.Dao.jdbc.impl;

public class BookDaobdImpl {
}
