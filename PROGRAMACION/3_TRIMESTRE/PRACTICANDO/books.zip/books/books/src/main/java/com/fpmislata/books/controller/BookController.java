package com.fpmislata.books.controller;

public class BookController {
}
