package com.fpmislata.books.domain.service.impl;

public class BookServiceImpl {
}
