package com.fpmislata.books.persistence.repository;

public interface BookRepository {
}
