package com.fpmislata.books.domain.service;

public interface BookService {
}
