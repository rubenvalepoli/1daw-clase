package com.fpmislata.books.persistence.Dao;

public interface BookDao {



}
