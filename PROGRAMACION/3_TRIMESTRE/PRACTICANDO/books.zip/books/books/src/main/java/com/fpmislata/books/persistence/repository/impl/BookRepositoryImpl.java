package com.fpmislata.books.persistence.repository.impl;

public class BookRepositoryImpl {
}
