package com.cipfpmislata.Ex3t_books.persistence.zdao.jdbc;

public class EditorialDaoJdbc {

}
