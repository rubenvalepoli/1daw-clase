package com.cipfpmislata.Ex3t_books.common.exceptions;


public class ServiceException extends RuntimeException{
    public ServiceException(String message){
        super(message);
    }
}
