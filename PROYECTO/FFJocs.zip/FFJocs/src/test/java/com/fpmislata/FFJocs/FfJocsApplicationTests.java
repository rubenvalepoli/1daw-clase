package com.fpmislata.FFJocs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FfJocsApplicationTests {

	@Test
	void contextLoads() {
	}

}
