package com.fpmislata.FFJocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FfJocsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FfJocsApplication.class, args);
	}

}
