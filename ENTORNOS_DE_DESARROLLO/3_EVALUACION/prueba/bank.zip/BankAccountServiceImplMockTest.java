package ud5.practices.bank;

import org.junit.jupiter.api.*;
import ud5.practices.bank.mock.BankAccountRepositoryMock;
import ud5.practices.bank.mock.NotificationServiceMock;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BankAccountServiceImplMockTest {
    private static BankAccountService bankAccountService;
    private List<BankAccount> bankAccountList = List.of(
            new BankAccount("123mr13","jorge",178.9),
            new BankAccount("1059kp","lucia",275.5),
            new BankAccount("3ws8n","marcos",341.4),
            new BankAccount("r23mr12","carla",287.1)
    );
    @Nested
    class FindAll{
        @BeforeEach
        void setUp() {
            bankAccountService = new BankAccountServiceImpl(
                    new BankAccountRepositoryMock(),
                    new NotificationServiceMock());
        }

        @Test
        @DisplayName("Return all accounts in list")
        void returnAllAccounts(){
            assertEquals(bankAccountList,bankAccountService.getAll());
        }
    }

    @Nested
    class FindByAccountNumber{
        @BeforeEach
        void setUp() {
            bankAccountService = new BankAccountServiceImpl(
                    new BankAccountRepositoryMock(),
                    new NotificationServiceMock());
        }

        @Test
        @DisplayName("Account number does not exist return null")
        void falseAccountNumberReturnNull(){
            assertThrows(BankAccountNotFoundException.class, () -> bankAccountService.getBankAccountByNumber("bbfslk32"));
        }

        @Test
        @DisplayName("Account number exists return banckaccount")
        void realAccountNumberReturnBankAccount() throws BankAccountNotFoundException {
            assertEquals(bankAccountList.get(0),bankAccountService.getBankAccountByNumber("123mr13"));
        }
    }


    @Nested
    class UpdateAccountHolderName{
        @BeforeEach
        void setUp() {
            bankAccountService = new BankAccountServiceImpl(
                    new BankAccountRepositoryMock(),
                    new NotificationServiceMock());
        }

        @Test
        @DisplayName("")
        void updateAccountHolder() {
        }
    }


}