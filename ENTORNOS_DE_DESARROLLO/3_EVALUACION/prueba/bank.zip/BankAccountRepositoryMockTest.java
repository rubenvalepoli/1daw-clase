package ud5.practices.bank;

public class BankAccountRepositoryMockTest {

}
