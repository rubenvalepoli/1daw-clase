package org.example.domain.service;

public interface IndicatorService {
    void showMaxSpeedIndicator(boolean showNotification);
}