# Exercici 1 - Ruben Valero Policarpo
Canvi 1
Canvi 2

